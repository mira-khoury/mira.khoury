var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const port= 4000;

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

app.get("/", function(req, res){
    res.sendFile(path.join(__dirname, "/views/cv.html"))
});

app.get('/customers', function(req, res){
    sql.query("SELECT * FROM customers", (err, mysqlres) => {
    if (err) {
        console.log("error: ", err);
        res.status(400).send({message: "error in getting all customers from table: " + err});
        return;
        }
    console.log("got all customers...");
    res.send(mysqlres);
    return;
    });
});

app.listen(port, ()=>{
    console.log(message= "helo to my site")
});


app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

module.exports = app;
