
function rename(){
    document.getElementById("tittle").innerHTML="WELCOME TO MY SITE";
}

