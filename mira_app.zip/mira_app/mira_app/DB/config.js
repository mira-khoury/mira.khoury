module.exports = {  
    HOST: "localhost",
    USER: "root",
    PASSWORD: "mira_KH123",
    DB: "mysql"
};